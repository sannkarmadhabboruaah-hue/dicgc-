import { redirect } from "next/navigation";

export default function Home() {
  redirect("/dicgc-optimizer.html");
}
